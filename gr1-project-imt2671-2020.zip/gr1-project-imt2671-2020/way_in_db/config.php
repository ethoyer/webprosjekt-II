
<?php
$db = new mysqli("localhost","root","","way_in");
if(!$db) die("database connection error");
?>